create table Area (
	cod_area int not null,
	descricao varchar(100),
	primary key (cod_area)
);